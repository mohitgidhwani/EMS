import axios from "axios";
import React, { useEffect, useState } from "react";
import { motion, pageVariants, staggerContainer, staggerItem } from "../../motion/Animated";

export default function Latest() {

    const [news, setNews] = useState([]);
    const [nextPage, setNextPage] = useState("");
    const [prevPages, setPrevPages] = useState([]);

    const fetchNews = (pageToken = "") => {

        axios.get(
            `https://newsdata.io/api/1/latest?apikey=pub_6866f08a213547c5868978fda1781d20&country=in,de&language=en&excludecategory=education,science,technology,world&removeduplicate=1`
        ).then((data) => {

            setNews(data.data.results);
            setNextPage(data.data.nextPage);

        }).catch((err) => {
            console.log("Error fetching news: " + err);
        });
    };

    useEffect(() => {
        fetchNews();
    }, []);

    const next = () => {
        if (!nextPage) return;
        setPrevPages([...prevPages, nextPage]);
        fetchNews(nextPage);
    };

    const prev = () => {
        if (prevPages.length === 0) return;
        const history = [...prevPages];
        const prevToken = history.pop();
        setPrevPages(history);
        fetchNews(prevToken);
    };

    return (
        <motion.div className="main-content" variants={pageVariants} initial="hidden" animate="visible">
            <div className="container-fluid news-container">
                <motion.div className="row" variants={staggerContainer} initial="hidden" animate="visible">
                    {news.map((item, index) => (
                        <motion.div className="col-lg-4 col-md-6 mb-4" key={index} variants={staggerItem}>
                            <div className="news-card">
                                <img
                                    src={item.image_url || "https://via.placeholder.com/400x200"}
                                    className="news-img"
                                    alt="news"
                                />
                                <div className="news-content">
                                    <h6 className="news-title">
                                        {item.title}
                                    </h6>
                                    <p className="news-desc">
                                        {item.description
                                            ? item.description.substring(0, 80) + "..."
                                            : "Click to read full article"}
                                    </p>
                                </div>
                            </div>
                        </motion.div>
                    ))}

                </motion.div>

                <div className="text-center mt-4">
                    <button
                        className="btn btn-secondary me-3"
                        onClick={prev}
                        disabled={prevPages.length === 0}
                    >
                        Previous
                    </button>
                    <button
                        className="btn btn-purple"
                        onClick={next}
                        disabled={!nextPage}
                    >
                        Next
                    </button>
                </div>
            </div>
        </motion.div>
    );
}