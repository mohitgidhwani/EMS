import { useEffect, useState } from 'react'
import './App.css'
import { BrowserRouter, Route, Routes } from 'react-router-dom'
import Home from './Home'
import Navbar from './Navbar'
import AddEmp from './AddEmp'
import EditEmp from './EditEmp'
import Sidebar from './Sidebar'
import Logs from './Logs'
import Register from './ServicesFile/Register'
import Login from './ServicesFile/Login'
import AuthContext from './AuthFile/AuthContext'
import Projects from './Pages/Projects'
import ReportPopup from './Popups/ReportPopup'
import AddEditProject from './AddPages.jsx/AddEditProject'
import Reports from './Pages/Reports'
import ReportViewPopup from './Popups/ReportViewPopUp'
import Manegment from './Pages/Manegment'
import Settings from './Pages/Settings'
import Latest from './Pages/News/Latest'
// import DeletePopup from './Popups/DeletePopup'

function App() {

  const [sidebarOpen, setSidebarOpen] = useState(false)

  // Apply saved preferences before the Settings page is visited.
  useEffect(() => {
    document.documentElement.setAttribute('data-theme', localStorage.getItem('theme') || 'light')
    document.documentElement.setAttribute('data-color-theme', localStorage.getItem('colorTheme') || 'blue')
  }, [])

  return (
    <>
      <AuthContext>
        <BrowserRouter>
          <Navbar onMenuClick={() => setSidebarOpen((o) => !o)}></Navbar>
          <Sidebar open={sidebarOpen} onClose={() => setSidebarOpen(false)}></Sidebar>
          <Routes>
            <Route path='/' element={<Home></Home>}>
              <Route path='register' element={<Register></Register>}></Route>
              <Route path='login' element={<Login></Login>}></Route>
              {/* <Route path='deletePopup' element={<DeletePopup></DeletePopup>}></Route> */}

            </Route>
            <Route path='/addEmployee' element={<AddEmp></AddEmp>}></Route>
            <Route path='/editEmployee/:id' element={<EditEmp></EditEmp>}></Route>
            <Route path='/logspage' element={<Logs></Logs>}></Route>
            <Route path="/Projects" element={<Projects></Projects>}>
              <Route path='report/:id' element={<ReportPopup></ReportPopup>}></Route>
              <Route path='addeditProject/:id' element={<AddEditProject></AddEditProject>}></Route>
              <Route path='addeditProject' element={<AddEditProject></AddEditProject>}></Route>
            </Route>
            <Route path='/reports' element={<Reports></Reports>}>
              <Route path='ReportViewPopup/:id' element={<ReportViewPopup></ReportViewPopup>}></Route>
            </Route>
            <Route path='/manegment' element={<Manegment></Manegment>}></Route>
            <Route path='/Settings' element={<Settings></Settings>}></Route>
            <Route path='/latestnews' element={<Latest></Latest>}></Route>
          </Routes>
        </BrowserRouter>
      </AuthContext>
    </>
  )
}

export default App
