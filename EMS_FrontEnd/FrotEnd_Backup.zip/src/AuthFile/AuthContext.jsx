import axios from 'axios';
import React, { createContext, useEffect, useState } from 'react'


export const AuthCon = createContext();

const getProfileCacheKey = (user) =>
    `ems-profile:${user.authName || user.name}:${user.authRole || user.role}`;

const readCachedProfile = (user) => {
    try {
        const cachedProfile = sessionStorage.getItem(getProfileCacheKey(user));
        return cachedProfile ? JSON.parse(cachedProfile) : null;
    } catch {
        return null;
    }
};

const cacheProfile = (user, profile) => {
    try {
        sessionStorage.setItem(getProfileCacheKey(user), JSON.stringify(profile));
    } catch {
        // A very large image can exceed browser storage limits; the API remains the fallback.
    }
};


function AuthContext({ children}) {
    const [user, setUser] = useState(null);
    const [profile, setProfile] = useState(null);
    const [profileLoading, setProfileLoading] = useState(false);

    useEffect(() => {
         axios.get("https://localhost:7238/api/Auth/LoggedInUser", { withCredentials: true })
            .then((res) => { setUser(res.data)})
            .catch(() => { setUser(null) })
    },[])

    useEffect(() => {
        if (!user) {
            setProfile(null);
            return;
        }

        const cachedProfile = readCachedProfile(user);
        if (cachedProfile) {
            setProfile(cachedProfile);
            setProfileLoading(false);
            return;
        }

        setProfileLoading(true);
        axios.get("https://localhost:7238/api/Auth/GetAllRegisterUser", { withCredentials: true })
            .then((res) => {
                const users = Array.isArray(res.data) ? res.data : [];
                const currentProfile = users.find(
                    (item) => item.authName === user.name && item.authRole === user.role
                ) || null;
                setProfile(currentProfile);
                if (currentProfile) cacheProfile(user, currentProfile);
            })
            .catch(() => setProfile(null))
            .finally(() => setProfileLoading(false));
    }, [user]);

    return (
        <AuthCon.Provider value={{ user, setUser, profile, profileLoading }}>
             {children}
        </AuthCon.Provider>
    )
}

export default AuthContext
